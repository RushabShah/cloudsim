#!/bin/sh
wget -P jars http://www.ee.ucl.ac.uk/~mflanaga/java/flanagan.jar
